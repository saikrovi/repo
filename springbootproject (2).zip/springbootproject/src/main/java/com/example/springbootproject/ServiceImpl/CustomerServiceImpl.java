package com.example.springbootproject.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.springbootproject.Model.Customer;
import com.example.springbootproject.Repository.CustomerRepository;
import com.example.springbootproject.Service.CustomerService;

@ Service
public class CustomerServiceImpl implements CustomerService {
	CustomerRepository customerRepository;

	@Override
	public Customer savecustomer(Customer customer) {
		String name=customer.getName();
		customer.setName(name);
	Customer custrespo=customerRepository.save(customer);
		return custrespo ;
	}

	@Override
	public void deleteCustmer(Integer id) {
		customerRepository.deletebyid(id);
	}

	

	@Override
	public List<Customer> findbyname(String name) {
		
		return customerRepository.findByname(name);
	}




	}



