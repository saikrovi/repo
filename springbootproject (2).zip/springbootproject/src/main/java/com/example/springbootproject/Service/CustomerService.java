package com.example.springbootproject.Service;

import java.util.List;
import java.util.Optional;

import com.example.springbootproject.Model.Customer;

public interface CustomerService {
	public Customer savecustomer(Customer customer);
	
	public void deleteCustmer(Integer id);
	
	
	
	public List<Customer> findbyname(String name);

	public Optional<Customer> getid(Integer id);

	Customer getbyCustomerId(Integer Id);

	

}
