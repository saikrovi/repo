package com.example.springbootproject.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.springbootproject.Model.Customer;
import com.example.springbootproject.Service.CustomerService;

import io.micrometer.core.ipc.http.HttpSender.Request;

@RestController
@RequestMapping("/cust")
public class CustomerController {
	@Autowired
	CustomerService customerService;
	
@RequestMapping(value="saveCust",method=RequestMethod.POST)
	public ResponseEntity<Customer>saveCustomer(@RequestBody Customer customer){
		Customer custrespo=customerService.savecustomer(customer);
	ResponseEntity<Customer> rs=new ResponseEntity<>(customer,HttpStatus.OK);
		return rs;
		
	}
@RequestMapping(value="update",method=RequestMethod.PUT)
       public ResponseEntity<Customer>updateCustomer(@RequestBody Customer customer){
				Customer custrespo=customerService.savecustomer(customer);
				ResponseEntity<Customer> rc=new ResponseEntity<>(customer,HttpStatus.OK);
				return rc;
    	   
       }
@RequestMapping(value="deleteCust/{id}",method=RequestMethod.DELETE)
      public ResponseEntity<String>deleteCustomer(@PathVariable Integer id){
	customerService.deleteCustmer(id);
		return new ResponseEntity<>("sucessfully delete"+id,HttpStatus.OK);
}
    
@RequestMapping(value="getCustid/{id}",method=RequestMethod.GET)        
     public ResponseEntity<Customer>getbyid(@PathVariable Integer id){
	Optional<Customer>cust=customerService.getid(id);
			
	return new ResponseEntity<Customer>(cust.orElseThrow(()->new IllegalArgumentException("user not avalible")),HttpStatus.OK); 

}

}
